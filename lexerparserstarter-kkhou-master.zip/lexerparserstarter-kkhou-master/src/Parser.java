public class Parser {
    //TODO implement Parser class here
}
